import sys

N = int(sys.argv[1])

with open('alice.txt', 'r', encoding ='utf-8') as f:
    text = f.read()

splited = text.lower().split()

dict = {}

for word in splited:
    if word in dict:
        dict[word] += 1
    else:
        dict[word] = 1


sorted_words = sorted(dict.items(), key = lambda item: item[1], reverse = True)

print(sorted_words)

top_words = sorted_words[:N]

for i, (word, count) in enumerate(top_words, 1):
    print(f'{i} - word "{word}" {count} times')



